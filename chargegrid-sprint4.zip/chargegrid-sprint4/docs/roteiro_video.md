# Roteiro do vídeo técnico (≤ 5 min)

| Tempo | Cena | O que mostrar / falar |
|---|---|---|
| 0:00–0:30 | Abertura | Nome ChargeGrid, equipe, problema: recarregar VEs com energia limpa e barata. Citar que a Sprint 3 era o nó de borda. |
| 0:30–1:15 | Arquitetura | `docs/img/arquitetura.png`. Explicar campo (Goodwe), borda (Arduino), core Python, interfaces. **Dizer claramente que o campo é simulado.** |
| 1:15–2:00 | Borda | Rodar `python edge/edge_bridge.py --demo` (ou o Wokwi da Sprint 3) e mostrar LIBERAR/ADIAR. |
| 2:00–3:15 | Simulação e algoritmo | Rodar `python run_simulation.py`. Abrir `perfil_dia.png`: Baseline vs Smart. Explicar as 4 regras (urgência, sol primeiro, previsão, reserva da bateria). |
| 3:15–4:15 | Dashboard e assistente | `streamlit run dashboard.py`: mexer no slider de kWp, mostrar KPIs. No chat perguntar "quanto gerei hoje?" e "qual a economia?". |
| 4:15–5:00 | Resultados e limites | Custo −25%, ponta −75%, 100% atendido; robustez 18% (9–33%). Citar limites: ganho depende do dimensionamento, pico de demanda piorou, dados simulados. Próximos passos: SEMS/Modbus real e previsão meteorológica. |

Dica: grave a tela com narração; deixe o terminal e o navegador com fonte grande.
